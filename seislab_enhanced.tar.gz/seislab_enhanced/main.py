#!/usr/bin/env python3
"""
SeisLab - Professional Seismic Analysis and Attribute Extraction GUI
Main Application Entry Point
"""

import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from gui.main_window import SeisLabApp


def main():
    """Initialize and run the SeisLab application."""
    # Enable high DPI scaling
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    app = QApplication(sys.argv)
    app.setApplicationName("SeisLab")
    app.setOrganizationName("SeisLab")
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = SeisLabApp()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

"""
Attribute Panel
Interface for computing and displaying seismic attributes
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                             QPushButton, QListWidget, QLabel, QComboBox,
                             QSpinBox, QProgressBar, QMessageBox)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
import numpy as np
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from attributes.rms import RMSAmplitude
from attributes.instantaneous import (InstantaneousAmplitude, 
                                     InstantaneousPhase,
                                     InstantaneousFrequency)


class AttributeComputeThread(QThread):
    """Thread for computing attributes without blocking UI."""
    
    finished = pyqtSignal(np.ndarray, str)
    error = pyqtSignal(str)
    
    def __init__(self, data, attr_type, window_size=25):
        super().__init__()
        self.data = data
        self.attr_type = attr_type
        self.window_size = window_size
        
    def run(self):
        """Compute attribute in background."""
        try:
            if self.attr_type == 'rms':
                calculator = RMSAmplitude(window_size=self.window_size)
            elif self.attr_type == 'inst_amp':
                calculator = InstantaneousAmplitude()
            elif self.attr_type == 'inst_phase':
                calculator = InstantaneousPhase()
            elif self.attr_type == 'inst_freq':
                calculator = InstantaneousFrequency()
            else:
                self.error.emit(f"Unknown attribute: {self.attr_type}")
                return
                
            result = calculator.compute(self.data)
            self.finished.emit(result, self.attr_type)
            
        except Exception as e:
            self.error.emit(str(e))


class AttributePanel(QWidget):
    """Panel for attribute extraction and display."""
    
    def __init__(self):
        super().__init__()
        
        self.current_attribute = None
        self.attribute_results = {}
        
        self.setup_ui()
        
    def setup_ui(self):
        """Initialize the user interface."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Left side - Controls
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 5, 0)
        
        # Attribute selection
        attr_group = QGroupBox("Attribute Selection")
        attr_layout = QVBoxLayout()
        
        self.attr_combo = QComboBox()
        self.attr_combo.addItems([
            "RMS Amplitude",
            "Instantaneous Amplitude",
            "Instantaneous Phase",
            "Instantaneous Frequency"
        ])
        attr_layout.addWidget(QLabel("Attribute Type:"))
        attr_layout.addWidget(self.attr_combo)
        
        self.window_spin = QSpinBox()
        self.window_spin.setMinimum(5)
        self.window_spin.setMaximum(101)
        self.window_spin.setValue(25)
        self.window_spin.setSingleStep(2)
        attr_layout.addWidget(QLabel("Window Size:"))
        attr_layout.addWidget(self.window_spin)
        
        self.btn_compute = QPushButton("Compute Attribute")
        self.btn_compute.clicked.connect(self.compute_selected_attribute)
        attr_layout.addWidget(self.btn_compute)
        
        attr_group.setLayout(attr_layout)
        left_layout.addWidget(attr_group)
        
        # Computed attributes list
        list_group = QGroupBox("Computed Attributes")
        list_layout = QVBoxLayout()
        
        self.attr_list = QListWidget()
        self.attr_list.itemClicked.connect(self.display_selected_attribute)
        list_layout.addWidget(self.attr_list)
        
        self.btn_export = QPushButton("Export Selected")
        self.btn_export.setEnabled(False)
        list_layout.addWidget(self.btn_export)
        
        list_group.setLayout(list_layout)
        left_layout.addWidget(list_group)
        
        left_layout.addStretch()
        
        # Right side - Display
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(5, 0, 0, 0)
        
        # Info label
        self.info_label = QLabel("Select an attribute to compute")
        self.info_label.setStyleSheet("""
            QLabel {
                padding: 8px;
                background-color: #e8f5e9;
                border: 1px solid #81c784;
                border-radius: 4px;
                font-weight: bold;
                color: #2e7d32;
            }
        """)
        right_layout.addWidget(self.info_label)
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        right_layout.addWidget(self.progress)
        
        # Matplotlib figure
        self.figure = Figure(figsize=(8, 6), facecolor='white')
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)
        right_layout.addWidget(self.canvas)
        
        # Add to main layout
        layout.addWidget(left_widget, 1)
        layout.addWidget(right_widget, 3)
        
        # Show empty plot
        self.show_empty_plot()
        
    def show_empty_plot(self):
        """Display empty plot with instructions."""
        self.ax.clear()
        self.ax.text(0.5, 0.5, 'Compute an attribute to view results',
                    ha='center', va='center', fontsize=14, color='#757575',
                    transform=self.ax.transAxes)
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        for spine in self.ax.spines.values():
            spine.set_visible(False)
        self.canvas.draw()
        
    def compute_selected_attribute(self):
        """Compute the selected attribute."""
        attr_name = self.attr_combo.currentText()
        
        if not hasattr(self, 'input_data') or self.input_data is None:
            QMessageBox.warning(self, "Warning", "No seismic data available.")
            return
            
        # Map attribute names to types
        attr_map = {
            "RMS Amplitude": "rms",
            "Instantaneous Amplitude": "inst_amp",
            "Instantaneous Phase": "inst_phase",
            "Instantaneous Frequency": "inst_freq"
        }
        
        attr_type = attr_map.get(attr_name)
        self.compute_attribute(attr_type, self.input_data)
        
    def compute_attribute(self, attr_type, data):
        """
        Compute seismic attribute.
        
        Args:
            attr_type: Type of attribute
            data: Input seismic data
        """
        self.input_data = data
        
        # Show progress
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.btn_compute.setEnabled(False)
        self.info_label.setText(f"Computing {attr_type}...")
        
        # Start computation thread
        self.compute_thread = AttributeComputeThread(
            data, attr_type, self.window_spin.value()
        )
        self.compute_thread.finished.connect(self.on_compute_finished)
        self.compute_thread.error.connect(self.on_compute_error)
        self.compute_thread.start()
        
    def on_compute_finished(self, result, attr_type):
        """Handle completed attribute computation."""
        self.progress.setVisible(False)
        self.btn_compute.setEnabled(True)
        
        # Store result
        self.attribute_results[attr_type] = result
        
        # Update list
        if attr_type not in [self.attr_list.item(i).text() 
                            for i in range(self.attr_list.count())]:
            self.attr_list.addItem(attr_type)
        
        # Display result
        self.display_attribute(result, attr_type)
        self.info_label.setText(f"Computed {attr_type} successfully")
        self.btn_export.setEnabled(True)
        
    def on_compute_error(self, error_msg):
        """Handle computation error."""
        self.progress.setVisible(False)
        self.btn_compute.setEnabled(True)
        QMessageBox.critical(self, "Error", f"Computation failed:\n{error_msg}")
        self.info_label.setText("Computation failed")
        
    def display_selected_attribute(self, item):
        """Display selected attribute from list."""
        attr_type = item.text()
        if attr_type in self.attribute_results:
            result = self.attribute_results[attr_type]
            self.display_attribute(result, attr_type)
            
    def display_attribute(self, data, attr_type):
        """
        Display attribute result.
        
        Args:
            data: Attribute data array
            attr_type: Attribute type name
        """
        self.ax.clear()
        self.current_attribute = data
        
        # Choose appropriate colormap
        if attr_type == 'inst_phase':
            cmap = 'hsv'
            vmin, vmax = -np.pi, np.pi
        elif attr_type == 'inst_freq':
            cmap = 'viridis'
            vmin, vmax = None, None
        else:
            cmap = 'hot'
            vmin, vmax = None, None
            
        # Plot
        im = self.ax.imshow(data.T, aspect='auto', cmap=cmap,
                           vmin=vmin, vmax=vmax, interpolation='bilinear')
        
        # Colorbar
        cbar = self.figure.colorbar(im, ax=self.ax, pad=0.02)
        cbar.set_label(attr_type.replace('_', ' ').title(), 
                      fontsize=10, weight='bold')
        
        # Labels
        self.ax.set_xlabel('Trace Number', fontsize=11, weight='bold')
        self.ax.set_ylabel('Time (samples)', fontsize=11, weight='bold')
        self.ax.set_title(f'{attr_type.replace("_", " ").title()} Attribute',
                         fontsize=13, weight='bold', pad=15)
        
        # Grid and styling
        self.ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
        self.ax.tick_params(labelsize=9)
        for spine in self.ax.spines.values():
            spine.set_edgecolor('#e0e0e0')
            spine.set_linewidth(1.5)
            
        self.figure.tight_layout()
        self.canvas.draw()

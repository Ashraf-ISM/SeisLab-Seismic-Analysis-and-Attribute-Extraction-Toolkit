"""
SeisLab Main Window
Professional GUI interface for seismic data analysis
"""

from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QTabWidget, QMenuBar, QMenu, QAction, QStatusBar,
                             QFileDialog, QMessageBox, QSplitter, QDockWidget,
                             QLabel, QPushButton, QComboBox, QSpinBox, QGroupBox,
                             QFormLayout, QDoubleSpinBox, QProgressBar, QToolBar)
from PyQt5.QtCore import Qt, pyqtSignal, QThread
from PyQt5.QtGui import QIcon, QPalette, QColor, QFont
import os

from gui.segy_viewer import SeismicViewer
from gui.attribute_panel import AttributePanel
from gui.processing_panel import ProcessingPanel
from gui.interpretation_panel import InterpretationPanel
from gui.info_panel import InfoPanel
from seismic.segy_loader import SegyLoader


class SeisLabApp(QMainWindow):
    """Main application window for SeisLab."""
    
    def __init__(self):
        super().__init__()
        
        # Application state
        self.segy_loader = None
        self.current_data = None
        self.current_inline = 0
        self.current_crossline = 0
        
        # Setup UI
        self.setup_ui()
        self.setup_menubar()
        self.setup_toolbar()
        self.setup_statusbar()
        self.connect_signals()
        self.apply_light_theme()
        
    def setup_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle("SeisLab - Seismic Analysis & Attribute Extraction")
        self.setGeometry(100, 100, 1600, 900)
        
        # Central widget with tabs
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(self.central_widget)
        
        # Create main splitter
        self.main_splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Controls and Information
        self.left_panel = self.create_left_panel()
        
        # Center panel - Visualization
        self.center_panel = self.create_center_panel()
        
        # Add to splitter
        self.main_splitter.addWidget(self.left_panel)
        self.main_splitter.addWidget(self.center_panel)
        self.main_splitter.setStretchFactor(0, 1)
        self.main_splitter.setStretchFactor(1, 4)
        
        main_layout.addWidget(self.main_splitter)
        
    def create_left_panel(self):
        """Create the left control panel."""
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(5, 5, 5, 5)
        
        # File information group
        self.info_panel = InfoPanel()
        left_layout.addWidget(self.info_panel)
        
        # Navigation group
        nav_group = QGroupBox("Navigation")
        nav_layout = QFormLayout()
        
        self.inline_spin = QSpinBox()
        self.inline_spin.setMinimum(0)
        self.inline_spin.setMaximum(9999)
        nav_layout.addRow("Inline:", self.inline_spin)
        
        self.crossline_spin = QSpinBox()
        self.crossline_spin.setMinimum(0)
        self.crossline_spin.setMaximum(9999)
        nav_layout.addRow("Crossline:", self.crossline_spin)
        
        self.view_mode = QComboBox()
        self.view_mode.addItems(["Inline View", "Crossline View", "Time Slice"])
        nav_layout.addRow("View Mode:", self.view_mode)
        
        nav_group.setLayout(nav_layout)
        left_layout.addWidget(nav_group)
        
        # Display settings group
        display_group = QGroupBox("Display Settings")
        display_layout = QFormLayout()
        
        self.colormap = QComboBox()
        self.colormap.addItems(["seismic", "gray", "viridis", "RdBu", "jet"])
        display_layout.addRow("Colormap:", self.colormap)
        
        self.gain_spin = QDoubleSpinBox()
        self.gain_spin.setMinimum(0.1)
        self.gain_spin.setMaximum(10.0)
        self.gain_spin.setValue(1.0)
        self.gain_spin.setSingleStep(0.1)
        display_layout.addRow("Gain:", self.gain_spin)
        
        self.clip_spin = QDoubleSpinBox()
        self.clip_spin.setMinimum(0.1)
        self.clip_spin.setMaximum(100.0)
        self.clip_spin.setValue(99.0)
        self.clip_spin.setSingleStep(1.0)
        display_layout.addRow("Clip %:", self.clip_spin)
        
        display_group.setLayout(display_layout)
        left_layout.addWidget(display_group)
        
        # Quick actions
        actions_group = QGroupBox("Quick Actions")
        actions_layout = QVBoxLayout()
        
        self.btn_compute_attributes = QPushButton("Compute Attributes")
        self.btn_compute_attributes.setEnabled(False)
        actions_layout.addWidget(self.btn_compute_attributes)
        
        self.btn_apply_filter = QPushButton("Apply Filter")
        self.btn_apply_filter.setEnabled(False)
        actions_layout.addWidget(self.btn_apply_filter)
        
        self.btn_ml_classify = QPushButton("ML Classification")
        self.btn_ml_classify.setEnabled(False)
        actions_layout.addWidget(self.btn_ml_classify)
        
        actions_group.setLayout(actions_layout)
        left_layout.addWidget(actions_group)
        
        left_layout.addStretch()
        
        return left_widget
        
    def create_center_panel(self):
        """Create the center visualization panel with tabs."""
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create tab widget
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.North)
        
        # Tab 1: Seismic Viewer
        self.seismic_viewer = SeismicViewer()
        self.tabs.addTab(self.seismic_viewer, "Seismic Viewer")
        
        # Tab 2: Attributes
        self.attribute_panel = AttributePanel()
        self.tabs.addTab(self.attribute_panel, "Attributes")
        
        # Tab 3: Processing
        self.processing_panel = ProcessingPanel()
        self.tabs.addTab(self.processing_panel, "Processing")
        
        # Tab 4: Interpretation
        self.interpretation_panel = InterpretationPanel()
        self.tabs.addTab(self.interpretation_panel, "Interpretation")
        
        center_layout.addWidget(self.tabs)
        
        return center_widget
        
    def setup_menubar(self):
        """Create the menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        self.action_open = QAction("Open SEG-Y...", self)
        self.action_open.setShortcut("Ctrl+O")
        file_menu.addAction(self.action_open)
        
        self.action_export = QAction("Export Data...", self)
        self.action_export.setShortcut("Ctrl+E")
        self.action_export.setEnabled(False)
        file_menu.addAction(self.action_export)
        
        file_menu.addSeparator()
        
        self.action_exit = QAction("Exit", self)
        self.action_exit.setShortcut("Ctrl+Q")
        file_menu.addAction(self.action_exit)
        
        # View menu
        view_menu = menubar.addMenu("View")
        
        self.action_reset_view = QAction("Reset View", self)
        view_menu.addAction(self.action_reset_view)
        
        self.action_fullscreen = QAction("Full Screen", self)
        self.action_fullscreen.setShortcut("F11")
        self.action_fullscreen.setCheckable(True)
        view_menu.addAction(self.action_fullscreen)
        
        # Attributes menu
        attr_menu = menubar.addMenu("Attributes")
        
        self.action_rms = QAction("RMS Amplitude", self)
        attr_menu.addAction(self.action_rms)
        
        self.action_inst_amp = QAction("Instantaneous Amplitude", self)
        attr_menu.addAction(self.action_inst_amp)
        
        self.action_inst_phase = QAction("Instantaneous Phase", self)
        attr_menu.addAction(self.action_inst_phase)
        
        self.action_inst_freq = QAction("Instantaneous Frequency", self)
        attr_menu.addAction(self.action_inst_freq)
        
        # Processing menu
        proc_menu = menubar.addMenu("Processing")
        
        self.action_bandpass = QAction("Bandpass Filter", self)
        proc_menu.addAction(self.action_bandpass)
        
        self.action_gain = QAction("Gain Control", self)
        proc_menu.addAction(self.action_gain)
        
        self.action_normalize = QAction("Normalize", self)
        proc_menu.addAction(self.action_normalize)
        
        # ML menu
        ml_menu = menubar.addMenu("Machine Learning")
        
        self.action_kmeans = QAction("K-Means Clustering", self)
        ml_menu.addAction(self.action_kmeans)
        
        self.action_dbscan = QAction("DBSCAN", self)
        ml_menu.addAction(self.action_dbscan)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        
        self.action_about = QAction("About SeisLab", self)
        help_menu.addAction(self.action_about)
        
        self.action_docs = QAction("Documentation", self)
        help_menu.addAction(self.action_docs)
        
    def setup_toolbar(self):
        """Create the toolbar."""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # Add actions to toolbar
        toolbar.addAction(self.action_open)
        toolbar.addSeparator()
        toolbar.addAction(self.action_export)
        toolbar.addSeparator()
        
    def setup_statusbar(self):
        """Create the status bar."""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.statusbar.addWidget(self.status_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setVisible(False)
        self.statusbar.addPermanentWidget(self.progress_bar)
        
    def connect_signals(self):
        """Connect signals and slots."""
        # File actions
        self.action_open.triggered.connect(self.load_segy)
        self.action_export.triggered.connect(self.export_data)
        self.action_exit.triggered.connect(self.close)
        
        # View actions
        self.action_reset_view.triggered.connect(self.reset_view)
        self.action_fullscreen.triggered.connect(self.toggle_fullscreen)
        
        # Navigation
        self.inline_spin.valueChanged.connect(self.update_inline)
        self.crossline_spin.valueChanged.connect(self.update_crossline)
        self.view_mode.currentIndexChanged.connect(self.change_view_mode)
        
        # Display settings
        self.colormap.currentTextChanged.connect(self.update_colormap)
        self.gain_spin.valueChanged.connect(self.update_gain)
        self.clip_spin.valueChanged.connect(self.update_clip)
        
        # Quick actions
        self.btn_compute_attributes.clicked.connect(self.show_attributes_tab)
        self.btn_apply_filter.clicked.connect(self.show_processing_tab)
        self.btn_ml_classify.clicked.connect(self.show_ml_dialog)
        
        # Attribute menu actions
        self.action_rms.triggered.connect(lambda: self.compute_attribute('rms'))
        self.action_inst_amp.triggered.connect(lambda: self.compute_attribute('inst_amp'))
        self.action_inst_phase.triggered.connect(lambda: self.compute_attribute('inst_phase'))
        self.action_inst_freq.triggered.connect(lambda: self.compute_attribute('inst_freq'))
        
        # Help actions
        self.action_about.triggered.connect(self.show_about)
        
    def load_segy(self):
        """Load a SEG-Y file."""
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Open SEG-Y File",
            "",
            "SEG-Y Files (*.sgy *.segy);;All Files (*)"
        )
        
        if filepath:
            try:
                self.statusbar.showMessage("Loading SEG-Y file...")
                self.progress_bar.setVisible(True)
                self.progress_bar.setRange(0, 0)  # Indeterminate
                
                # Load data
                self.segy_loader = SegyLoader(filepath)
                self.segy_loader.load_data()
                
                # Update UI
                self.update_file_info()
                self.enable_controls()
                
                # Display first inline
                self.display_current_section()
                
                self.statusbar.showMessage(f"Loaded: {os.path.basename(filepath)}", 5000)
                self.progress_bar.setVisible(False)
                
            except Exception as e:
                self.progress_bar.setVisible(False)
                QMessageBox.critical(self, "Error", f"Failed to load SEG-Y file:\n{str(e)}")
                self.statusbar.showMessage("Failed to load file", 5000)
                
    def update_file_info(self):
        """Update file information panel."""
        if self.segy_loader:
            info = self.segy_loader.get_info()
            self.info_panel.update_info(info)
            
            # Update navigation ranges
            self.inline_spin.setMaximum(info.get('n_inlines', 1) - 1)
            self.crossline_spin.setMaximum(info.get('n_crosslines', 1) - 1)
            
    def enable_controls(self):
        """Enable controls after data is loaded."""
        self.action_export.setEnabled(True)
        self.btn_compute_attributes.setEnabled(True)
        self.btn_apply_filter.setEnabled(True)
        self.btn_ml_classify.setEnabled(True)
        
    def display_current_section(self):
        """Display the current seismic section."""
        if not self.segy_loader:
            return
            
        view_mode = self.view_mode.currentText()
        
        try:
            if view_mode == "Inline View":
                data = self.segy_loader.get_inline(self.current_inline)
            elif view_mode == "Crossline View":
                data = self.segy_loader.get_crossline(self.current_crossline)
            else:  # Time Slice
                data = self.segy_loader.get_timeslice(self.current_inline)
                
            if data is not None:
                self.current_data = data
                self.seismic_viewer.display_section(
                    data,
                    colormap=self.colormap.currentText(),
                    gain=self.gain_spin.value(),
                    clip=self.clip_spin.value()
                )
                
        except Exception as e:
            QMessageBox.warning(self, "Warning", f"Could not display section:\n{str(e)}")
            
    def update_inline(self, value):
        """Update inline number."""
        self.current_inline = value
        if self.view_mode.currentText() in ["Inline View", "Time Slice"]:
            self.display_current_section()
            
    def update_crossline(self, value):
        """Update crossline number."""
        self.current_crossline = value
        if self.view_mode.currentText() == "Crossline View":
            self.display_current_section()
            
    def change_view_mode(self):
        """Change visualization mode."""
        self.display_current_section()
        
    def update_colormap(self):
        """Update colormap."""
        self.display_current_section()
        
    def update_gain(self):
        """Update gain value."""
        self.display_current_section()
        
    def update_clip(self):
        """Update clip percentage."""
        self.display_current_section()
        
    def reset_view(self):
        """Reset view to default."""
        self.seismic_viewer.reset_view()
        
    def toggle_fullscreen(self, checked):
        """Toggle fullscreen mode."""
        if checked:
            self.showFullScreen()
        else:
            self.showNormal()
            
    def show_attributes_tab(self):
        """Show attributes tab."""
        self.tabs.setCurrentWidget(self.attribute_panel)
        
    def show_processing_tab(self):
        """Show processing tab."""
        self.tabs.setCurrentWidget(self.processing_panel)
        
    def show_ml_dialog(self):
        """Show ML classification dialog."""
        QMessageBox.information(
            self,
            "ML Classification",
            "Machine Learning classification will be available in this section."
        )
        
    def compute_attribute(self, attr_type):
        """Compute a seismic attribute."""
        if not self.segy_loader or self.current_data is None:
            QMessageBox.warning(self, "Warning", "Please load seismic data first.")
            return
            
        self.attribute_panel.compute_attribute(attr_type, self.current_data)
        self.tabs.setCurrentWidget(self.attribute_panel)
        
    def export_data(self):
        """Export processed data."""
        if self.current_data is None:
            QMessageBox.warning(self, "Warning", "No data to export.")
            return
            
        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Export Data",
            "",
            "NumPy Files (*.npy);;CSV Files (*.csv);;All Files (*)"
        )
        
        if filepath:
            try:
                import numpy as np
                if filepath.endswith('.npy'):
                    np.save(filepath, self.current_data)
                elif filepath.endswith('.csv'):
                    np.savetxt(filepath, self.current_data, delimiter=',')
                    
                self.statusbar.showMessage(f"Exported to {os.path.basename(filepath)}", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Export failed:\n{str(e)}")
                
    def show_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self,
            "About SeisLab",
            "<h3>SeisLab v1.0</h3>"
            "<p>Professional Seismic Analysis & Attribute Extraction</p>"
            "<p>A comprehensive tool for seismic data interpretation, "
            "attribute extraction, and machine learning analysis.</p>"
            "<p><b>Features:</b></p>"
            "<ul>"
            "<li>SEG-Y data loading and visualization</li>"
            "<li>Advanced attribute extraction</li>"
            "<li>Signal processing filters</li>"
            "<li>Machine learning classification</li>"
            "<li>Interactive interpretation tools</li>"
            "</ul>"
        )
        
    def apply_light_theme(self):
        """Apply professional light theme."""
        palette = QPalette()
        
        # Light theme colors
        palette.setColor(QPalette.Window, QColor(245, 245, 245))
        palette.setColor(QPalette.WindowText, QColor(33, 33, 33))
        palette.setColor(QPalette.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.AlternateBase, QColor(240, 240, 240))
        palette.setColor(QPalette.ToolTipBase, QColor(255, 255, 220))
        palette.setColor(QPalette.ToolTipText, QColor(33, 33, 33))
        palette.setColor(QPalette.Text, QColor(33, 33, 33))
        palette.setColor(QPalette.Button, QColor(240, 240, 240))
        palette.setColor(QPalette.ButtonText, QColor(33, 33, 33))
        palette.setColor(QPalette.BrightText, QColor(255, 0, 0))
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, QColor(255, 255, 255))
        
        self.setPalette(palette)
        
        # Set stylesheet for additional styling
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QMenuBar {
                background-color: #ffffff;
                border-bottom: 1px solid #e0e0e0;
                padding: 4px;
            }
            QMenuBar::item {
                padding: 4px 12px;
                background-color: transparent;
            }
            QMenuBar::item:selected {
                background-color: #e3f2fd;
            }
            QMenu {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
            }
            QMenu::item:selected {
                background-color: #e3f2fd;
            }
            QToolBar {
                background-color: #fafafa;
                border-bottom: 1px solid #e0e0e0;
                spacing: 5px;
                padding: 5px;
            }
            QPushButton {
                background-color: #2a82da;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976d2;
            }
            QPushButton:pressed {
                background-color: #1565c0;
            }
            QPushButton:disabled {
                background-color: #bdbdbd;
                color: #757575;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                margin-top: 12px;
                padding-top: 12px;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #2a82da;
            }
            QTabWidget::pane {
                border: 1px solid #e0e0e0;
                background-color: white;
                border-radius: 4px;
            }
            QTabBar::tab {
                background-color: #f5f5f5;
                border: 1px solid #e0e0e0;
                padding: 8px 20px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: white;
                border-bottom-color: white;
                font-weight: bold;
                color: #2a82da;
            }
            QTabBar::tab:hover {
                background-color: #e3f2fd;
            }
            QStatusBar {
                background-color: #fafafa;
                border-top: 1px solid #e0e0e0;
            }
            QSpinBox, QDoubleSpinBox, QComboBox {
                padding: 6px;
                border: 1px solid #d0d0d0;
                border-radius: 4px;
                background-color: white;
            }
            QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
                border: 2px solid #2a82da;
            }
        """)
